

import UIKit

 /*let urls = ["https://www.google.co.in/imgres?imgurl=https%3A%2F%2Fwww.cats.org.uk%2Fuploads%2Fimages%2Ffeaturebox_sidebar_kids%2Fgrief-and-loss.jpg&imgrefurl=https%3A%2F%2Fwww.cats.org.uk%2F&docid=-uCj01WW3BLRtM&tbnid=B3B6q7ZifCm2kM%3A&vet=10ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwhwKAcwBw..i&w=582&h=328&bih=611&biw=1366&q=cats&ved=0ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwhwKAcwBw&iact=mrc&uact=8","https://www.google.co.in/imgres?imgurl=https%3A%2F%2Fr.hswstatic.com%2Fw_907%2Fgif%2Ftesla-cat.jpg&imgrefurl=https%3A%2F%2Fanimals.howstuffworks.com%2Fpets%2Fteslas-cat-and-other-feline-fascinations.htm&docid=yTPSYBCDHgIU0M&tbnid=GTJT8CqjTKEtwM%3A&vet=10ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwhsKAMwAw..i&w=907&h=510&bih=611&biw=1366&q=cats&ved=0ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwhsKAMwAw&iact=mrc&uact=8","https://www.google.co.in/imgres?imgurl=https%3A%2F%2Fwww.rd.com%2Fwp-content%2Fuploads%2F2016%2F04%2F01-cat-wants-to-tell-you-laptop.jpg&imgrefurl=https%3A%2F%2Fwww.rd.com%2Fadvice%2Fpets%2Fhow-to-decode-your-cats-behavior%2F&docid=mvBf4-NuAmclGM&tbnid=WJTnHdXVzqil9M%3A&vet=10ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwh7KBIwEg..i&w=2400&h=1600&bih=611&biw=1366&q=cats&ved=0ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwh7KBIwEg&iact=mrc&uact=8","https://www.google.co.in/imgres?imgurl=https%3A%2F%2Fwww.popsci.com%2Fsites%2Fpopsci.com%2Ffiles%2Fstyles%2F1000_1x_%2Fpublic%2Fimport%2F2014%2F5827857531_8962f29333_o.jpg%3Fitok%3Db0be33M8&imgrefurl=https%3A%2F%2Fwww.popsci.com%2Farticle%2Fscience%2Fsorry-cat-haters-science-isnt-your-side&docid=UHv65PnlOWZrHM&tbnid=MxkKDN4eGuf87M%3A&vet=10ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwiTASgdMB0..i&w=1000&h=932&bih=611&biw=1366&q=cats&ved=0ahUKEwjluevH_9_eAhXBr48KHSZCBKIQMwiTASgdMB0&iact=mrc&uact=8"]*/

let urls = ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFii8BNaHCvkv4aMmXNI2ukIgiE317IbkTAUyfKM8MCJghJBeQkA","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKDIb0urSmxAA5_0O3r5L34XTcIrc6C5iO1gz0lgwHKVgKumzE","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNT8YosiQA1hzL2s_Kv2KentoA41jEJp0nYVbz7qo2MWmFElHSiw","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSn2btarRgIEa_d3KEaIVzj1_aLu4UJhvy9T0snCbO-LsYv-wyn"]

class downloader
{
    class func downloadImg(url:String) -> UIImage!
    {
        var data = Data()
        do
        {
            data = try! Data(contentsOf: URL(string: url)!)
        }
        catch
        {
            return nil
        }
        return UIImage(data: data)
    }
}
class ViewController: UIViewController
{
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var stp: UIStepper!
    @IBOutlet weak var lbl: UILabel!
    
    var queue = OperationQueue()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func stpAction(_ sender: Any)
    {
        lbl.text = String(Int(stp.value))
    }
    
    @IBAction func Operation(_ sender: Any)
    {
        queue = OperationQueue()
        
        //Operation 1
        let ope1 =  BlockOperation(block:
        {
            let pic1 = downloader.downloadImg(url: urls[0])
            OperationQueue.main.addOperation({
                self.img1.image = pic1
            })
        })
        ope1.completionBlock = { print("Operation 1 completed, cancelled : \(ope1.isCancelled)")
        }
        queue.addOperation(ope1)
        
        //Operation 2
        let ope2 = BlockOperation {
            let pic2 = downloader.downloadImg(url: urls[1])
            OperationQueue.main.addOperation({
                self.img2.image = pic2
            })
        }
        ope2.addDependency(ope1)
        ope2.completionBlock = {    print("Operation 2 completes, cancelled : \(ope2.isCancelled)")
        }
        queue.addOperation(ope2)
    
        //Operation 3
        let ope3 = BlockOperation {
            let pic3 = downloader.downloadImg(url: urls[2])
            OperationQueue.main.addOperation({
                self.img3.image = pic3
            })
        }
        ope3.addDependency(ope2)
        ope3.completionBlock = {    print("Operation 3 completed, cancelled : \(ope3.isCancelled)")
        }
        queue.addOperation(ope3)
        
        //Operation 4
        let ope4 = BlockOperation {
            let pic4 = downloader.downloadImg(url: urls[3])
            OperationQueue.main.addOperation({
                self.img4.image = pic4
            })
        }
        ope4.addDependency(ope3)
        ope4.completionBlock = {    print("Operation 4 completed, cancelled : \(ope4.isCancelled)")
        }
        queue.addOperation(ope4)
    }
    
    @IBAction func serial(_ sender: Any)
    {
        let serialQueue = DispatchQueue(label: "com.appcoda.imagesQueue",  attributes: [])
        
        //Image 1
        serialQueue.async
        {
            let pic1 = downloader.downloadImg(url: urls[0])
            DispatchQueue .main.async(execute: {
                self.img1.image = pic1
            })
        }
        
        //image 2
        serialQueue.async
        {
            let pic2 = downloader.downloadImg(url: urls[1])
            DispatchQueue.main.async(execute: {
                self.img2.image = pic2
            })
        }
        
        //Image 3
        serialQueue.async
        {
            let pic3 = downloader.downloadImg(url: urls[2])
            DispatchQueue.main.async(execute: {
                self.img3.image = pic3
            })
        }
        
        //Image 4
        serialQueue.async {
            let pic4 = downloader.downloadImg(url: urls[3])
            DispatchQueue.main.async(execute: {
                self.img4.image = pic4
            })
        }
    }
    
    
    @IBAction func cancel(_ sender: Any)
    {
        queue.cancelAllOperations()
    }
    
}

